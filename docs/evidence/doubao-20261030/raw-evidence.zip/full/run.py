"""Full frozen-bank observer. Only documented thinking.disabled transport option added; no prompt or business rule edits."""
import concurrent.futures, importlib.util, json, os, pathlib, subprocess, sys, threading, time, urllib.request, urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
R=pathlib.Path(__file__).resolve().parent
MODEL='doubao-seed-2-1-pro-260915'
ENDPOINT='https://ark.cn-beijing.volces.com/api/v3/chat/completions'
stop=threading.Event();lock=threading.Lock();bad_transport=0
def write(p,v):
    temp=p.with_suffix(p.suffix+'.tmp');temp.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf8');temp.replace(p)
def stop_all(cause,status):
    with lock:
        if stop.is_set():return
        stop.set();write(R/'STOP.json',{'cause':cause,'httpStatus':status,'time':time.time()})
        for phase in ['base','continuation']:
            for s in range(4):
                folder=R/phase/str(s)
                if folder.exists():write(folder/'STOP.json',{'cause':cause,'httpStatus':status})
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args):return None
class Server(ThreadingHTTPServer):
    daemon_threads=False
def run(key,phase,s):
    global bad_transport
    folder=R/phase/str(s);folder.mkdir(parents=True)
    cases=json.loads((R/f'{phase}-{s}.json').read_text(encoding='utf8'))
    state={'phase':phase,'shard':s,'calls':0,'replays':0,'state':'RUNNING','started':time.time()}
    local_lock=threading.Lock()
    replay={}
    for c in cases:
        if 'continuationAudit' in c:replay.setdefault(c['continuationAudit']['frozenInput'],[]).append(c)
    class Relay(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def do_POST(self):
            global bad_transport
            if stop.is_set():self.send_error(503);return
            payload=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            row={'payload':payload,'started':time.time()};raw=b'{}';status=504
            content=payload['messages'][-1]['content']
            with local_lock:case=replay[content].pop(0) if replay.get(content) else None
            if case is not None:
                raw=json.dumps({'choices':[{'finish_reason':'stop','message':{'content':json.dumps(case['continuationAudit']['frozenCandidate'],ensure_ascii=False)}}]},ensure_ascii=False).encode()
                row.update(mode='CURRENT_RUN_CANDIDATE_REPLAY',caseId=case['id']);status=200
                with local_lock:state['replays']+=1
            else:
                with local_lock:state['calls']+=1;row['index']=state['calls']
                row.update(mode='LIVE_'+phase.upper(),endpoint=ENDPOINT)
                try:
                    assert payload['model']==MODEL
                    op=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
                    upstream={**payload,'thinking':{'type':'disabled'}};row['upstreamPayload']=upstream;row['transportOverride']='thinking.disabled'
                    req=urllib.request.Request(ENDPOINT,data=json.dumps(upstream,ensure_ascii=False).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer '+key})
                    try:response=op.open(req,timeout=30)
                    except urllib.error.HTTPError as e:response=e
                    with response:
                        status=response.status;raw=response.read(1048577);row['requestId']=response.headers.get('x-request-id')
                    if len(raw)>1048576:raise ValueError('Oversize response')
                    with lock:bad_transport=0
                except Exception as e:
                    row.update(error=type(e).__name__,causeType=type(getattr(e,'reason',e)).__name__,message=str(e).replace(key,'[REDACTED]'))
                    with lock:bad_transport+=1;n=bad_transport
                    if n>=5:stop_all('REPEATED_TRANSPORT_FAILURE',status)
            row.update(httpStatus=status,elapsed=time.time()-row['started'],body=raw.decode('utf8','replace').replace(key,'[REDACTED]'))
            with local_lock:
                with (folder/'network.jsonl').open('a',encoding='utf8') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
                write(folder/'status.json',state)
            if status in [400,401,402,403,429] or 'insufficient_quota' in row['body']:stop_all('API_BLOCK',status)
            try:
                self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
            except OSError:row['callerDisconnected']=True
    server=Server(('127.0.0.1',0),Relay);threading.Thread(target=server.serve_forever,daemon=True).start()
    env=os.environ.copy();env['QINGYE_LLM_TIMEOUT_MS']='18000'
    cmd=[r'D:\IDEA\JDK17\bin\java.exe','-Dfile.encoding=UTF-8','-cp',(R/'classpath.txt').read_text(encoding='utf8'),'FourGateProbe',f'http://127.0.0.1:{server.server_port}',str(R/f'{phase}-{s}.json'),str(folder),'doubao',MODEL]
    try:
        with (folder/'native.log').open('w',encoding='utf8') as log:
            child=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,creationflags=subprocess.CREATE_NO_WINDOW)
            state['pid']=child.pid
            with local_lock:write(folder/'status.json',state)
            state['exitCode']=child.wait()
        if state['exitCode']!=0:stop_all('NATIVE_PROCESS_FAILURE',state['exitCode'])
        summary=json.loads((folder/'summary.json').read_text(encoding='utf8'))
        if summary['state'] not in ['COMPLETED','API_BLOCKED']:stop_all('NATIVE_BOUNDARY_FAILURE',None)
    finally:
        server.shutdown();server.server_close()
        state['state']='FINISHED';state['finished']=time.time();write(folder/'status.json',state)
    return state
def rows(phase):
    return [json.loads(l) for s in range(4) for l in (R/phase/str(s)/'results.jsonl').read_text(encoding='utf8').splitlines()]
if __name__=='__main__':
    key=json.loads(sys.stdin.readline())['key']
    try:
        spec=importlib.util.spec_from_file_location('grade',R/'grade.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
        g.oracle=json.loads((R/'business-oracle.json').read_text(encoding='utf8'))
        supplements=json.loads((R/'supplements.json').read_text(encoding='utf8'))
        with concurrent.futures.ThreadPoolExecutor(4) as pool:
            for f in concurrent.futures.as_completed([pool.submit(run,key,'base',s) for s in range(4)]):print(json.dumps(f.result()),flush=True)
        if stop.is_set():raise RuntimeError('Stopped; retained evidence in STOP.json')
        initial=rows('base');assert len(initial)==391
        selected=[]
        for x in initial:
            grade=g.grade(x);f=x['finalResult'];q=g.oracle[x['caseId']]
            if len(x['observations'])!=1 or len(x['modelAttempts'])!=1 or f.get('gateRound')!=1:continue
            if grade['verdict']!='WRONG' and not(f['status']=='CLARIFY' and q is not None):continue
            c=dict(x['case']);c['turns']=[c['turns'][0],supplements[x['caseId']]]
            c['continuationAudit']={'firstVerdict':grade['verdict'],'frozenCandidate':x['modelAttempts'][0]['candidate'],'frozenInput':x['modelAttempts'][0]['input']}
            assert c['continuationAudit']['frozenCandidate'] is not None
            selected.append(c)
        write(R/'continuation-selection.json',selected)
        for s in range(4):write(R/f'continuation-{s}.json',selected[s::4])
        print('CONTINUATION_TASKS '+str(len(selected)),flush=True)
        with concurrent.futures.ThreadPoolExecutor(4) as pool:
            for f in concurrent.futures.as_completed([pool.submit(run,key,'continuation',s) for s in range(4)]):print(json.dumps(f.result()),flush=True)
        if stop.is_set():raise RuntimeError('Stopped; retained evidence in STOP.json')
        write(R/'finished.json',{'completed':True,'tasks':391,'secondRoundTasks':len(selected),'finished':time.time()})
    except Exception as e:
        write(R/'runner-error.json',{'type':type(e).__name__,'message':str(e).replace(key,'[REDACTED]')});raise
    finally:key=None
