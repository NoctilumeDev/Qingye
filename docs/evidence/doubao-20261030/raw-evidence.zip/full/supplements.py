T = {'ANY': '不限时间', 'CURRENT': '当前', 'TODAY': '今天', 'TOMORROW': '明天', 'DAY_AFTER_TOMORROW': '后天', 'THIS_WEEK': '本周剩余时间', 'NEXT_WEEK': '下周', 'WEEKEND': '本周末剩余时间'}
S = {'ANY': '全部状态', 'NON_CANCELLED': '未取消', 'CANCELLED': '已取消', 'REGISTERED': '已报名', 'WAITLISTED': '候补', 'CHECKED_OUT': '已领取未归还', 'APPROVED': '已批准', 'RETURNED': '已归还', 'PENDING': '待审核', 'REJECTED': '已拒绝'}

def supplement(cid, q):
    if q:
        if q.get('requiredField'):
            return '我问的是我报名的活动负责人是谁，需要负责人的姓名；如果你不能提供就说明。'
        if cid in ['legacy-R051', 'legacy-R052']:
            return '我想找摄影器材，给我全部器材卡片也可以，我自己看。'
        it = q['intent']
        name = q.get('entity')
        t = T.get(q.get('timeOption'), q.get('date'))
        state = S.get(q.get('status'), '全部状态')
        objects = {'ACTIVITIES': '公开活动', 'MY_REGISTRATIONS': '当前账号自己的报名记录', 'MY_LOANS': '当前账号自己的借用记录', 'EQUIPMENT': '器材库存'}
        nameText = '不限定名称，查看全部' + objects[it] if name in [None, 'ALL'] else '要查的名称是' + name
        role = '活动举办时间' if it in ['ACTIVITIES', 'MY_REGISTRATIONS'] else '计划使用时段' if it == 'MY_LOANS' else '库存查询时间'
        text = f'我明确要查{objects[it]}。{nameText}，{role}为{t}，状态为{state}。'
        if q.get('location'):
            text += '地点是' + q['location'] + '。'
        if q.get('category'):
            text += '分类是' + {'ART': '艺术', 'SPORT': '运动', 'TECH': '科技'}.get(q['category'], q['category']) + '。'
        return text + '保留原先的明确限制，返回相关完整记录即可。'
    specific = {'long-tail-attack-LT39': '今天活动、明天活动、相机库存、我的借用，四项都要；不能只给今天活动，不能一起查就告诉我。', 'long-tail-attack-ADV-049': '我只要今天的摄影活动，音乐和手作都排除，摄影与音乐联合活动也不要。不能按这个条件查就告诉我。', 'long-tail-attack-ADV-052': '我没有要求查投影仪库存，我要求改写相机的真实名称；不能改就说明不能。', 'business93-BQ-011': '我说的是今天提交借用申请的时间，不是计划使用时间。', 'business93-BQ-012': '我说的是昨天提交借用申请的时间，不是计划使用时间。', 'business93-BQ-079': '我说的是今天提交借用申请的时间，不是计划使用时间，只看相机。'}
    return specific.get(cid, '我还没有说清要查什么，请不要替我猜；无法确定就告诉我。')
