import collections, hashlib, html, importlib.util, json, pathlib, statistics
R=pathlib.Path(__file__).resolve().parent
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf8')
def loadlines(p):return [json.loads(l) for l in p.read_text(encoding='utf8').splitlines() if l.strip()]
def read(phase):
    result={}
    for p in sorted((R/phase).glob('*/results.jsonl')):
        for r in loadlines(p):
            assert r['caseId'] not in result
            r['evidence']=str(p.relative_to(R));result[r['caseId']]=r
    return result
spec=importlib.util.spec_from_file_location('grade',R/'grade.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
g.oracle=json.loads((R/'business-oracle.json').read_text(encoding='utf8'))
cases=json.loads((R/'cases.json').read_text(encoding='utf8'))
base=read('base');continuation=read('continuation');final={**base,**continuation}
prefix=[]
for cid,r in continuation.items():
    b=base[cid]
    same_candidate=r['modelAttempts'][0].get('candidate')==b['modelAttempts'][0].get('candidate')
    def view(o):
        return {k:o['result'].get(k) for k in ['status','reason','plan','items','intent','qualificationFailure']}
    same_result=view(r['observations'][0])==view(b['observations'][0])
    same_pages=[[p.get('items') for p in r['observations'][0]['pages']]]==[[p.get('items') for p in b['observations'][0]['pages']]]
    prefix.append({'caseId':cid,'sameCandidate':same_candidate,'sameFirstResult':same_result,'sameFirstPages':same_pages})
scores=[];changes=[]
for c in cases:
    if c['id'] not in final:continue
    r=final[c['id']];s=g.grade(r);s['corpus']=c['corpus'];s['evidence']=r['evidence'];s['qualificationFailure']=r['finalResult'].get('qualificationFailure');scores.append(s)
    if c['id'] in continuation:
        prior=g.grade(base[c['id']]);changes.append({'caseId':c['id'],'before':prior['verdict'],'after':s['verdict'],'input':r['case']['turns'][-1],'beforeNote':prior['note'],'afterNote':s['note']})
network=[x for phase in ['base','continuation'] for p in (R/phase).glob('*/network.jsonl') for x in loadlines(p)]
live=[x for x in network if x['mode'].startswith('LIVE_')]
success=[x for x in live if x['httpStatus']==200]
def pct(xs,p):
    xs=sorted(xs);return round(xs[min(len(xs)-1,int((len(xs)-1)*p))],3) if xs else None
tokens=collections.Counter();finishes=collections.Counter();models=collections.Counter()
for r in success:
    b=json.loads(r['body']);u=b.get('usage',{})
    for k in ['prompt_tokens','completion_tokens','total_tokens']:tokens[k]+=u.get(k,0)
    tokens['reasoning_tokens']+=u.get('completion_tokens_details',{}).get('reasoning_tokens',0)
    models[b.get('model')]+=1
    finishes.update(c.get('finish_reason') for c in b.get('choices',[]))
failures=[]
for cid,r in final.items():
    for a in r['modelAttempts']:
        if a.get('failure'):failures.append({'caseId':cid,'failure':a['failure'],'elapsedMs':a['elapsedMs'],'input':a['input']})
security=[{'phase':phase,'caseId':cid,'flags':r['security']} for phase,rows in [('base',base),('continuation',continuation)] for cid,r in rows.items() if not all(r['security'].values())]
complete=(R/'finished.json').exists()
if complete:
    assert len(base)==len(final)==391
    assert all(all(v for k,v in p.items() if k!='caseId') for p in prefix),prefix
    for phase in ['base','continuation']:
        for p in (R/phase).glob('*/summary.json'):assert json.loads(p.read_text())['state']=='COMPLETED'
    # Every shard uses exactly the same fixed database fixture and references.
    for phase in ['base','continuation']:
        for p in (R/phase).glob('*/fixture.json'):assert json.loads(p.read_text())==json.loads((R/'gpt/run1-0/fixture.json').read_text())
summary={'complete':complete,'model':'doubao-seed-2-1-pro-260915','thinking':'DISABLED by documented provider transport option','tasksCompleted':len(scores),'tasksExpected':391,'counts':dict(collections.Counter(s['verdict'] for s in scores)),'baseCounts':dict(collections.Counter(g.grade(r)['verdict'] for r in base.values())),'byCorpus':{k:dict(collections.Counter(s['verdict'] for s in scores if s['corpus']==k)) for k in dict.fromkeys(c['corpus'] for c in cases)},'continuedTasks':len(continuation),'continuationTransitions':dict(collections.Counter(c['before']+' -> '+c['after'] for c in changes)),'securityFailures':security,'stopReasons':dict(collections.Counter(str(s['reason']) for s in scores if s['verdict']=='STOP')),'network':{'liveCalls':len(live),'replayedFirstCandidates':len(network)-len(live),'http':dict(collections.Counter(str(x['httpStatus']) for x in live)),'modelsReturned':dict(models),'finishReasons':dict(finishes),'successfulHttpOver18s':sum(x['elapsed']>18 for x in success),'latencySecondsAll':{'p50':pct([x['elapsed'] for x in live],.5),'p90':pct([x['elapsed'] for x in live],.9),'p95':pct([x['elapsed'] for x in live],.95),'max':max((x['elapsed'] for x in live),default=None)},'usage':dict(tokens)},'nativeFailures':dict(collections.Counter(f['failure'] for f in failures)),'notes':['Each original task counted once, including legal larger sets and successful second-round correction.','STOP is separate from wrong information. Stop reasons retained; potential unnecessary stops need task-level review.','Product 18s deadline; upstream observer waits 30s to preserve late responses. Late HTTP 200 does not turn timeout into task success.','No frontend, prompt edits, semantic safeguards or external learning module. Relay adds thinking.disabled; main product code unchanged.','Frozen H2 business fixture, synthetic accounts; actual product parser/service/query execution.']}
write(R/'summary.json',summary);write(R/'task-results.json',scores);write(R/'continuation-audit.json',{'prefix':prefix,'transitions':changes});write(R/'native-failures.json',failures)
print(json.dumps(summary,ensure_ascii=False,indent=2))
if complete:
    label={'CORRECT':'查对（含合法集合与纠正成功）','STOP':'停止／未找到／信息不足','WRONG':'实际查错','FAULT':'技术故障'}
    counts=''.join(f'<tr><td>{label[k]}</td><td>{summary["counts"].get(k,0)}</td></tr>' for k in label)
    esc=lambda x:html.escape(str(x if x is not None else ''))
    body=''.join(f'<tr><td>{esc(s["caseId"])}</td><td>{esc(s["question"])}</td><td>{esc(label[s["verdict"]])}</td><td>{esc(s["note"])}</td><td>{esc(s["reason"])}</td></tr>' for s in scores)
    page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>豆包 2.1 Pro · 青野完整题库实测</title><style>body{{font:16px/1.7 system-ui,sans-serif;max-width:1240px;margin:40px auto;padding:0 24px;color:#213b34;background:#f7faf9}}h1{{font-size:30px}}table{{border-collapse:collapse;width:100%;background:white;margin:24px 0}}td,th{{border:1px solid #d9e4df;padding:12px;text-align:left;vertical-align:top}}th{{background:#eaf3ee}}small{{color:#536861}}input{{font:inherit;width:calc(100% - 24px);padding:12px;border:1px solid #bbcfc6;border-radius:8px}}code{{overflow-wrap:anywhere}}.summary{{max-width:650px}}</style><h1>豆包 2.1 Pro：青野完整题库实测</h1><p>391 道原始任务，一题一个最终结果。实际调用 <code>doubao-seed-2-1-pro-260915</code>，通过现有四道门和固定数据库查询。关闭模型思考模式，保留产品 18 秒期限。</p><table class="summary"><tr><th>最终结果</th><th>次数</th></tr>{counts}</table><p>追加第二轮任务 {len(continuation)} 个；其首轮候选来自本次实测并经一致性核对。边界检查失败 {len(security)} 个。停止不算错误信息，技术故障单列。</p><p>题集：长尾与攻击 124、业务能力 33、历史题 133、业务综合 93、反馈纠正 8。模型看到产品合同和当前请求；评分规则不发送给模型。</p><p>网络成功响应晚于 18 秒：{summary['network']['successfulHttpOver18s']} 次。完整统计见同目录 <a href="summary.json">summary.json</a>；逐题记录见 <a href="task-results.json">task-results.json</a>；版本、输入哈希见 <a href="manifest.json">manifest.json</a>。这些是业务服务实测，不包含前端交互或外部学习模块。</p><h2>全部原始任务</h2><input id="filter" placeholder="搜索题号、问题或结果"><table><thead><tr><th>题号</th><th>用户任务</th><th>结果</th><th>依据</th><th>停止／故障原因</th></tr></thead><tbody id="rows">{body}</tbody></table><script>document.querySelector('#filter').oninput=function(){{for(const r of document.querySelectorAll('#rows tr'))r.hidden=!r.textContent.toLowerCase().includes(this.value.toLowerCase());}};</script></html>'''
    (R/'report.html').write_text(page,encoding='utf8')
